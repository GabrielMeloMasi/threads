import javax.sound.sampled.*;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.util.concurrent.CountDownLatch;

public class Main {
    public static void main(String[] args) {
        System.out.println("Escolha uma opção:");
        System.out.println("1 - Atirar");
        System.out.println("2 - Correr");
        System.out.println("3 - Chorar");

        Scanner scanner = new Scanner(System.in);
        String escolha = scanner.nextLine();

        switch (escolha) {
            case "1":
                tocarAudio("C:\\Users\\Aluno\\IdeaProjects\\Threads\\gun-shots-230534.wav");
                break;
            case "2":
                tocarAudio("C:\\Users\\Aluno\\IdeaProjects\\Threads\\person-running-loop-245173.wav");
                break;
            case "3":
                tocarAudio("C:\\Users\\Aluno\\IdeaProjects\\Threads\\baby-crying-loud-100441.wav");
                break;
            default:
                System.out.println("Opção inválida.");
                break;
        }

        scanner.close();
    }

    // Função para tocar o áudio
    private static void tocarAudio(String caminhoArquivo) {
        // Usando um CountDownLatch para aguardar o término do áudio
        CountDownLatch latch = new CountDownLatch(1);

        try {
            // Cria um objeto File com o caminho do arquivo de áudio
            File arquivo = new File(caminhoArquivo);

            // Cria um objeto AudioInputStream para ler o áudio
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(arquivo);

            // Obtém um Clip de áudio e abre o stream de áudio
            Clip clip = AudioSystem.getClip();
            clip.open(audioStream);

            // Adiciona um Listener para capturar o evento de finalização
            clip.addLineListener(event -> {
                if (event.getType() == LineEvent.Type.STOP) {
                    // O áudio terminou de tocar, conta a espera
                    latch.countDown();
                    System.out.println("Áudio finalizado!");
                }
            });

            clip.start();

            latch.await();

        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException | InterruptedException e) {
            System.out.println("Erro ao tocar o áudio: " + e.getMessage());
        }
    }
}
